package com.example.qejani_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
