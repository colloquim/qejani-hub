// utils/app_constants.dart
import 'package:flutter/material.dart';

class AppConstants {
  static const primaryColor = 0xFF0D47A1; // Example blue
  static const secondaryColor = 0xFF1976D2;
  static const currency = 'KSh';
}
